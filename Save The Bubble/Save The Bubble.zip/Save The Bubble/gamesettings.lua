-----------------------------------------------------------------------------------------
--
-- gamesettings.lua A lua file to hold all variables that will be saved in documents directory to persist between sessions
--
-----------------------------------------------------------------------------------------
local M = {}

return M;